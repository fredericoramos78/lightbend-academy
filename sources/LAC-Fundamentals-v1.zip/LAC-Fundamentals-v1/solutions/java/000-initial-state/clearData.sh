#!/usr/bin/env bash

echo "REMOVING DATA IN ./tmp"

set -x
rm -rf tmp
