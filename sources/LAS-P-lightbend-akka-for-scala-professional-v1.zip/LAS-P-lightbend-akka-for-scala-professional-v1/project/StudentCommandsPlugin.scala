package sbtstudent

import sbt.Keys._
import sbt._
import Navigation.{loadBookmark, setupNavAttrs}

import scala.Console

object StudentCommandsPlugin extends AutoPlugin {
  // Deprecated this file. Left here for overwrite purposes.
}
